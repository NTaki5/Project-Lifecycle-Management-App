<?php
$this->view("/includes/header");
// echo Toast::show("show toast-onload");
?>


<div class="container-fluid">
    <!-- start Custom Icon Tab -->
    <div class="card">
        <div class="card-body">

            <h4 class="card-title mb-4">Projects</h4>
            <div>

                <!-- Nav tabs -->
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item me-4 h-100">
                        <a href="projects/create" class="justify-content-center w-100 btn btn-secondary d-flex align-items-center" fdprocessedid="hvxcfy">
                            <i class="ti ti-folder fs-7 me-2"></i>
                            Create Project
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link d-flex h-100 align-items-center active" data-bs-toggle="tab" href="#All" role="tab">
                            <span>
                                <i class="ti ti-clear-all"></i>
                            </span>
                            <span class="d-none d-md-block ms-2">All</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link d-flex h-100 align-items-center" data-bs-toggle="tab" href="#started" role="tab">
                            <span>
                                <i class="ti ti-player-play"></i>
                            </span>
                            <span class="d-none d-md-block ms-2">Started</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link d-flex h-100 align-items-center" data-bs-toggle="tab" href="#ready" role="tab">
                            <span>
                                <i class="ti ti-player-play"></i>
                            </span>
                            <span class="d-none d-md-block ms-2">Ready</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link d-flex h-100 align-items-center" data-bs-toggle="tab" href="#approval" role="tab">
                            <span>
                                <i class="ti ti-writing-sign"></i>
                            </span>
                            <span class="d-none d-md-block ms-2">Approval</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link d-flex h-100 align-items-center" data-bs-toggle="tab" href="#completed" role="tab">
                            <span>
                                <i class="ti ti-circle-check"></i>
                            </span>
                            <span class="d-none d-md-block ms-2">Completed</span>
                        </a>
                    </li>
                </ul>
                <!-- Tab panes -->
                <div class="tab-content mt-5">
                    <div class="tab-pane p-3 active" id="All" role="tabpanel">
                        <div class="row">
                        <?php 
                        echo $projectClass->getProjectsCards($projects);
                        
                        ?>
                        </div>
                    </div>
                    <div class="tab-pane p-3" id="started" role="tabpanel">
                        <div class="row">
                        <?php 
                            echo $projectClass->getProjectsCards($projects,'started');
                        ?>
                        </div>
                    </div>
                    <div class="tab-pane p-3" id="ready" role="tabpanel">
                        <div class="row">
                        <?php 
    
                           echo $projectClass->getProjectsCards($projects, 'ready');

                        ?>
                        </div>
                    </div>
                    <div class="tab-pane p-3" id="approval" role="tabpanel">
                        <div class="row">
                        <?php 
    
                        echo $projectClass->getProjectsCards($projects,'approval');
                        ?>
                        </div>
                    </div>
                    <div class="tab-pane p-3" id="completed" role="tabpanel">
                        <div class="row">
                        <?php 
                        
                        echo $projectClass->getProjectsCards($projects,'completed');
                        ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end Custom Icon Tab -->
</div>
<?php
$this->view("/includes/footer");
?>
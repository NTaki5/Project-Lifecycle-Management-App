<?php

class Document extends Model{

    protected $allowedColumns = ["fk_project_id", "fk_feed_id", "document_name", "type", "name"];

    

}
<?php

class Feed extends Model{

    protected $allowedColumns = ["fk_parent_id", "fk_user_id", "fk_project_id", "fk_company_id","message", "date", "show", "likes"];



}
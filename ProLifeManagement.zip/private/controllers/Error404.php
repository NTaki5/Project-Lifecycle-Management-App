<?php 

class Error404 extends Controller{


    function index(){
        $this->view("404");
    }
}
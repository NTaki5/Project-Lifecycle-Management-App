<?php

define('ROOT', 'http://localhost/ProLifeManagement/public');

define('CONTROLLERS_PATH', '../private/controllers/');
define('VIEWS_PATH', '../private/views/');
define('MODELS_PATH', '../private/models/');

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'projectlifecyclemanagmentapp');

define('SMTP_HOST', 'sandbox.smtp.mailtrap.io');
define('SMTP_USERNAME', '40f8378f6aa25a');
define('SMTP_PASSWORD', '1f50c4cb4ad601');
define('SMTP_SENDER', 'takacsn525@gmail.com');
define('SMTP_SENDER_NAME', 'Project Lifecycle CMS');

// define('SMTP_HOST', 'localhost');
// define('SMTP_USERNAME', 'test@localhost');
// define('SMTP_PASSWORD', '51]Bn]7I:2t3');
// define('SMTP_SENDER', 'takacsn525@gmail.com');
// define('SMTP_SENDER_NAME', 'Project Lifecycle CMS');


// hMailServer password = 51]Bn]7I:2t3

//define('MAILER_PATH', '../../mailer/');